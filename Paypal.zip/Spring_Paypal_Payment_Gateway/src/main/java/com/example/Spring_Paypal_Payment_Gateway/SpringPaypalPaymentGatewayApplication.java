package com.example.Spring_Paypal_Payment_Gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPaypalPaymentGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPaypalPaymentGatewayApplication.class, args);
	}

}
